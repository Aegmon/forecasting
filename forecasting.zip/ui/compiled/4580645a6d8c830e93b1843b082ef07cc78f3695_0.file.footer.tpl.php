<?php
/* Smarty version 3.1.39, created on 2024-10-25 07:10:58
  from '/home/u545031325/domains/financialforcast.online/public_html/ui/theme/ibilling/sections/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_671ad402d23b20_99973071',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4580645a6d8c830e93b1843b082ef07cc78f3695' => 
    array (
      0 => '/home/u545031325/domains/financialforcast.online/public_html/ui/theme/ibilling/sections/footer.tpl',
      1 => 1729647785,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_671ad402d23b20_99973071 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['tplfooter']->value).".tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
