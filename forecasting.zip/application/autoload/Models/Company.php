<?php
class Models_Company extends Model
{
    public static $_table = 'sys_companies';
}
