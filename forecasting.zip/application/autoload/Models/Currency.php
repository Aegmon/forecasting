<?php
class Models_Currency extends Model
{
    public static $_table = 'sys_currencies';
}
