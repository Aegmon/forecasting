<?php
class Models_Permission extends Model
{
    public static $_table = 'sys_permissions';
}
