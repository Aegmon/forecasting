<?php
if(!defined('APP_RUN')) exit('No direct access allowed');
$file_build = '4900';
require 'vendor/autoload.php';
require 'application/helpers/ibilling_bootstrap.php';
