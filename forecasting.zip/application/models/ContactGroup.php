<?php
use Illuminate\Database\Eloquent\Model;

class ContactGroup extends Model
{
    protected $table = 'crm_groups';
    public $timestamps = false;
}