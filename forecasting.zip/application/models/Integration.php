<?php
use Illuminate\Database\Eloquent\Model;

class Integration extends Model
{
    protected $table = 'clx_integrations';
}