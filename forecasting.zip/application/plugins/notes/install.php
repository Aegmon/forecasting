<?php
$t = new Schema('app_notes');
$t->add('title');
$t->add('contents');
$t->save();




